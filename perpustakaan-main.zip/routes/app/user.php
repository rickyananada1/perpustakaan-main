<?php

use Illuminate\Support\Facades\Route;

Route::group(['domain' => ''], function() {
});
// Route::get('/', function(){
//     return view('pages.office.auth.main');
// });