<?php

use App\Http\Controllers\HomeController;
use App\Http\Controllers\TaskController;
use Illuminate\Support\Facades\Route;


// Route::get('/', [HomeController::class, 'index']);
// Route::get('task', [TaskController::class, 'index']);
// Route::get('task/create', [TaskController::class, 'create']);
