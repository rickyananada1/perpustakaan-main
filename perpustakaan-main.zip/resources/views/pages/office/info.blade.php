<x-OfficeLayout title="Tentang">
    <div class="container-fluid">
        <!-- Basic Card Example -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Pengembang</h6>
                </div>
                <div class="card-body">
                    Website ini dikelola dan dikembangkan untuk membantu para pengunjung perpustakaan Lumban Dolok
                </div>
            </div>
                        <!-- Collapsable Card Example -->
                <div class="card shadow mb-4">
                    <!-- Card Header - Accordion -->
                    <a href="#collapseCardExample" class="d-block card-header py-3" data-toggle="collapse" role="button" aria-expanded="true" aria-controls="collapseCardExample">
                    <h6 class="m-0 font-weight-bold text-primary">Versi Website</h6>
                    </a>
                    <!-- Card Content - Collapse -->
                    <div class="collapse " id="collapseCardExample">
                    <div class="card-body">
                        Sistem Manajemen Perpustakaan Lumban Dolok Versi 1.0
                    </div>
                    </div>
                </div>
    </div>
</x-OfficeLayout>