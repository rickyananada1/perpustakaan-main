<script src="{{asset('offices/vendor_sb/jquery/jquery.min.js ') }}"></script>
<script src="{{asset('offices/vendor_sb/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{asset('offices/vendor_sb/jquery-easing/jquery.easing.min.js') }}"></script>
<script src="{{asset('offices/vendor_sb/chart.js/Chart.min.js ') }}"></script>
<script src="{{asset('offices/js/sweetalert2.min.js') }}"></script>
<script src="{{asset('offices/js/sb-admin-2.js') }}"></script>
<script src="{{asset('offices/vendor_sb/datatables/jquery.dataTables.min.js')}}"></script>
<script src="{{asset('offices/vendor_sb/datatables/dataTables.bootstrap4.min.js')}}"></script>
<script src="{{asset('offices/js/plugin.js')}}"></script>
<script src="{{asset('offices/js/functions.js')}}"></script>
<script src="{{asset('offices/js/toastr.js')}}"></script>
<script src="{{asset('offices/js/confirm.js')}}"></script>
<script src="{{asset('offices/js/regex.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>

<script src="https://kit.fontawesome.com/fd8370ec87.js" crossorigin="anonymous"></script>