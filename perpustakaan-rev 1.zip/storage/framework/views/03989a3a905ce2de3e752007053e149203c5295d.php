 <!-- Modal -->
<div class="modal fade" id="categoryModal" tabindex="-1" role="dialog" aria-labelledby="categoryModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" id="contentCategoryModal">
           
        </div>
    </div>
</div>

<div class="modal fade" id="bookModal" tabindex="-1" role="dialog" aria-labelledby="bookModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" id="contentBookModal">
            
        </div>
    </div>
</div>

<div class="modal fade" id="memberModal" tabindex="-1" role="dialog" aria-labelledby="memberModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" id="contentMemberModal">
           
        </div>
    </div>
</div>

<div class="modal fade" id="employeeModal" tabindex="-1" role="dialog" aria-labelledby="employeeModal" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content" id="contentEmployeeModal">
           
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\perpustakaan-l8-h\resources\views/theme/office/modal.blade.php ENDPATH**/ ?>